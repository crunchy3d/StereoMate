# StereoMate — desktop program (Windows / Linux)

Automatic alignment of stereoscopic images. Programmed by Damir Vrančić and Claude, 2026.
Program licence: MIT (see `LICENSE`; the copyright notice must be kept in all copies). OpenCV.js: Apache-2.0 (`dist/opencv-LICENSE.txt`).

This project wraps the program (`dist/index.html`, the same file as `StereoMate_V_0_xxx.html`)
with [Tauri](https://tauri.app) into a desktop program with full access to files and folders.
GitHub builds it automatically for Windows and Linux.

## What is built

| System  | Files |
|---------|-------|
| Windows | `StereoMate_<version>_portable.exe` (no installation), `StereoMate_…_x64-setup.exe` (installer), `StereoMate_…_x64_en-US.msi` (installer) |
| Linux   | `…_amd64.AppImage` (no installation: make it executable and start it), `…_amd64.deb` (Debian / Ubuntu / Mint) |

Windows needs the WebView2 runtime, which is part of Windows 10 and 11 (the installers download it if missing).

## Getting the files

* **After every upload / change** (push to `main`): tab **Actions** → the latest run of *Build desktop program* →
  at the bottom **Artifacts**: `Windows` and `Linux` (zip files, you must be logged in).
* **As a release** (nicer download page): tab **Releases** → *Draft a new release* → *Choose a tag* → type e.g. `v0.34.0`
  → *Create new tag* → *Publish release*. The build runs again and attaches all files to the release.
* **Build again manually**: Actions → *Build desktop program* → *Run workflow*.

A build takes about 10–15 minutes (the first one is the slowest).

## Updating to a new version of the program

The GitHub repository contains only the project zip (exactly one `.zip` file) and `.github/workflows/build.yml`,
which unpacks the zip and builds it. For a new version you get a new zip: delete the old zip in the repository and upload the new one.

Inside the zip: `dist/index.html` is the program; the version number is in `package.json`, `src-tauri/tauri.conf.json`
and `src-tauri/Cargo.toml` (e.g. `0.101.0`). Note: Windows installers (MSI) allow at most 255 for the middle number.

## Structure

```
dist/                  the program (index.html, opencv.js, licence)
src-tauri/
  src/lib.rs           file access commands (read, write, list, delete / recycle bin, command line)
  tauri.conf.json      window, installers, file associations (.mpo, .jps, .jpg)
  capabilities/        permissions of the window
  icons/               program icons
.github/workflows/build.yml   automatic build for Windows and Linux
```

## Building on your own computer (optional)

Install Rust (https://rustup.rs), Node.js, and on Windows the "Desktop development with C++" tools of Visual Studio Build Tools;
on Linux the packages `libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev libayatana-appindicator3-dev patchelf`. Then:

```
npm ci
npx tauri build
```
