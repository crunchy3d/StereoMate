//! Desktop shell of "StereoMate": the program itself is the HTML/JavaScript page in ../dist,
//! these commands give it direct access to files and folders.
use serde::Serialize;
use std::io::{Read, Seek, SeekFrom};
use std::time::UNIX_EPOCH;
use tauri::ipc::{InvokeBody, Request, Response};

#[derive(Serialize)]
struct Info {
    name: String,
    is_dir: bool,
    size: u64,
    mtime: f64, // milliseconds since 1970 (like File.lastModified)
}

fn info(name: String, md: &std::fs::Metadata) -> Info {
    let mtime = md
        .modified()
        .ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0);
    Info { name, is_dir: md.is_dir(), size: md.len(), mtime }
}

/// Whole file as binary data (ArrayBuffer in JavaScript)
#[tauri::command]
fn read_file(path: String) -> Result<Response, String> {
    std::fs::read(&path).map(Response::new).map_err(|e| format!("{path}: {e}"))
}

/// Part of a file (e.g. the EXIF header)
#[tauri::command]
fn read_file_range(path: String, start: u64, len: u64) -> Result<Response, String> {
    let mut f = std::fs::File::open(&path).map_err(|e| format!("{path}: {e}"))?;
    f.seek(SeekFrom::Start(start)).map_err(|e| e.to_string())?;
    let mut buf = Vec::new();
    f.take(len).read_to_end(&mut buf).map_err(|e| e.to_string())?;
    Ok(Response::new(buf))
}

/// Write a file: the data is the raw request body, the path is in the header "x-path" (URL-encoded)
#[tauri::command]
fn write_file(request: Request<'_>) -> Result<(), String> {
    let InvokeBody::Raw(data) = request.body() else {
        return Err("write_file: binary data expected".into());
    };
    let enc = request
        .headers()
        .get("x-path")
        .and_then(|v| v.to_str().ok())
        .ok_or("write_file: path missing")?;
    let path = urlencoding::decode(enc).map_err(|e| e.to_string())?.into_owned();
    std::fs::write(&path, data).map_err(|e| format!("{path}: {e}"))
}

// Writes binary data at a position of an existing (or new) file — used for large files written in pieces (videos)
#[tauri::command]
fn write_at(request: Request<'_>) -> Result<(), String> {
    use std::io::{Seek, SeekFrom, Write};
    let InvokeBody::Raw(data) = request.body() else {
        return Err("write_at: binary data expected".into());
    };
    let h = request.headers();
    let enc = h.get("x-path").and_then(|v| v.to_str().ok()).ok_or("write_at: path missing")?;
    let path = urlencoding::decode(enc).map_err(|e| e.to_string())?.into_owned();
    let offset: u64 = h.get("x-offset").and_then(|v| v.to_str().ok()).and_then(|v| v.parse().ok()).unwrap_or(0);
    let mut f = std::fs::OpenOptions::new().write(true).create(true).open(&path).map_err(|e| format!("{path}: {e}"))?;
    f.seek(SeekFrom::Start(offset)).map_err(|e| format!("{path}: {e}"))?;
    f.write_all(data).map_err(|e| format!("{path}: {e}"))
}

#[tauri::command]
fn stat_path(path: String) -> Result<Info, String> {
    let md = std::fs::metadata(&path).map_err(|e| format!("{path}: {e}"))?;
    let name = std::path::Path::new(&path)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default();
    Ok(info(name, &md))
}

#[tauri::command]
fn read_dir(path: String) -> Result<Vec<Info>, String> {
    let mut out = Vec::new();
    for e in std::fs::read_dir(&path).map_err(|e| format!("{path}: {e}"))?.flatten() {
        if let Ok(md) = std::fs::metadata(e.path()) {
            out.push(info(e.file_name().to_string_lossy().into_owned(), &md));
        }
    }
    out.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(out)
}

#[tauri::command]
fn make_dir(path: String) -> Result<(), String> {
    std::fs::create_dir_all(&path).map_err(|e| format!("{path}: {e}"))
}

/// Delete a file permanently (only after the user confirmed it)
#[tauri::command]
fn remove_path(path: String) -> Result<(), String> {
    std::fs::remove_file(&path).map_err(|e| format!("{path}: {e}"))
}

/// Move files to the Recycle Bin / Trash
#[tauri::command]
fn trash_paths(paths: Vec<String>) -> Result<(), String> {
    trash::delete_all(&paths).map_err(|e| e.to_string())
}

/// Files or folders given on the command line ("Open with", double-click on an associated file)
#[tauri::command]
fn cli_paths() -> Vec<String> {
    std::env::args().skip(1).filter(|a| !a.starts_with('-')).collect()
}


/* ---------- ffmpeg (an ffmpeg program chosen by the user; started only when needed) ---------- */
use std::collections::HashMap;
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::{Arc, Mutex, OnceLock};

struct OutBuf {
    data: Vec<u8>,
    eof: bool,
}
struct Proc {
    child: Child,
    stdin: Arc<Mutex<Option<ChildStdin>>>,
    log: Arc<Mutex<String>>,
    out: Option<Arc<(Mutex<OutBuf>, std::sync::Condvar)>>,
}
fn procs() -> &'static Mutex<HashMap<u32, Proc>> {
    static P: OnceLock<Mutex<HashMap<u32, Proc>>> = OnceLock::new();
    P.get_or_init(|| Mutex::new(HashMap::new()))
}
fn no_window(c: &mut Command) -> &mut Command {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x0800_0000); // CREATE_NO_WINDOW: no console window for ffmpeg
    }
    c
}
#[derive(Serialize)]
struct FfInfo {
    path: String,
    version: String,
    encoders: Vec<String>,
}
fn ff_try(path: &str) -> Option<FfInfo> {
    let out = no_window(&mut Command::new(path)).args(["-hide_banner", "-encoders"]).stdin(Stdio::null()).output().ok()?;
    if !out.status.success() {
        return None;
    }
    let txt = String::from_utf8_lossy(&out.stdout).into_owned();
    let encoders = txt
        .lines()
        .filter_map(|l| {
            let t = l.trim_start();
            if t.starts_with('V') { t.split_whitespace().nth(1).map(|s| s.to_string()) } else { None }
        })
        .collect();
    let v = no_window(&mut Command::new(path)).arg("-version").stdin(Stdio::null()).output().ok();
    let version = v.map(|o| String::from_utf8_lossy(&o.stdout).lines().next().unwrap_or("").to_string()).unwrap_or_default();
    Some(FfInfo { path: path.to_string(), version, encoders })
}
/// Finds ffmpeg: the given path, else next to this program, else on the PATH
#[tauri::command]
async fn ffmpeg_info(path: String) -> Result<FfInfo, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let mut cand: Vec<String> = Vec::new();
        if !path.is_empty() {
            cand.push(path.clone());
        } else {
            if let Ok(exe) = std::env::current_exe() {
                if let Some(d) = exe.parent() {
                    cand.push(d.join(if cfg!(windows) { "ffmpeg.exe" } else { "ffmpeg" }).to_string_lossy().into_owned());
                }
            }
            cand.push("ffmpeg".into());
        }
        for c in cand {
            if let Some(i) = ff_try(&c) {
                return Ok(i);
            }
        }
        Err(if path.is_empty() { "ffmpeg not found".into() } else { format!("{path}: not a working ffmpeg program") })
    })
    .await
    .map_err(|e| e.to_string())?
}
/// Starts ffmpeg with the given arguments; data is sent with ffmpeg_write (stdin), and with read = true
/// its output (stdout, e.g. decoded frames) is collected for ffmpeg_read
#[tauri::command]
fn ffmpeg_start(path: String, args: Vec<String>, read: Option<bool>) -> Result<u32, String> {
    let read = read.unwrap_or(false);
    let mut child = no_window(&mut Command::new(&path))
        .args(&args)
        .stdin(Stdio::piped())
        .stdout(if read { Stdio::piped() } else { Stdio::null() })
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| format!("{path}: {e}"))?;
    let mut outb = None;
    if read {
        if let Some(mut so) = child.stdout.take() {
            let ob = Arc::new((Mutex::new(OutBuf { data: Vec::new(), eof: false }), std::sync::Condvar::new()));
            let o2 = ob.clone();
            std::thread::spawn(move || {
                let mut buf = vec![0u8; 1 << 20];
                loop {
                    let n = so.read(&mut buf).unwrap_or(0);
                    let (m, cv) = &*o2;
                    let mut g = m.lock().unwrap();
                    if n == 0 { g.eof = true; cv.notify_all(); break; }
                    // keep at most ~256 MB waiting (the program reads it in order)
                    while g.data.len() > 256 << 20 { g = cv.wait(g).unwrap(); }
                    g.data.extend_from_slice(&buf[..n]);
                    cv.notify_all();
                }
            });
            outb = Some(ob);
        }
    }
    let log = Arc::new(Mutex::new(String::new()));
    if let Some(mut err) = child.stderr.take() {
        let l = log.clone();
        std::thread::spawn(move || {
            let mut buf = [0u8; 4096];
            while let Ok(n) = err.read(&mut buf) {
                if n == 0 { break; }
                let mut s = l.lock().unwrap();
                s.push_str(&String::from_utf8_lossy(&buf[..n]));
                if s.len() > 20000 { let cut = s.len() - 12000; let mut k = cut; while !s.is_char_boundary(k) { k += 1; } s.drain(..k); }
            }
        });
    }
    let id = child.id();
    let stdin = Arc::new(Mutex::new(child.stdin.take()));
    procs().lock().unwrap().insert(id, Proc { child, stdin, log, out: outb });
    Ok(id)
}
/// Up to max bytes of ffmpeg's output (waits up to 10 s for data); error "EOF" at the end
#[tauri::command]
async fn ffmpeg_read(id: u32, max: u32) -> Result<Response, String> {
    let ob = procs().lock().unwrap().get(&id).and_then(|p| p.out.clone()).ok_or("ffmpeg output not available")?;
    tauri::async_runtime::spawn_blocking(move || {
        let (m, cv) = &*ob;
        let mut g = m.lock().unwrap();
        let t0 = std::time::Instant::now();
        while g.data.is_empty() && !g.eof && t0.elapsed().as_secs() < 10 {
            g = cv.wait_timeout(g, std::time::Duration::from_millis(200)).unwrap().0;
        }
        if g.data.is_empty() && g.eof { return Err("EOF".to_string()); }
        let n = g.data.len().min(max as usize);
        let v: Vec<u8> = g.data.drain(..n).collect();
        cv.notify_all();
        Ok(Response::new(v))
    })
    .await
    .map_err(|e| e.to_string())?
}
#[derive(Serialize)]
struct FfStatus {
    running: bool,
    code: i32,
    log: String,
}
/// Is ffmpeg still running? (with its messages, e.g. the progress)
#[tauri::command]
fn ffmpeg_status(id: u32) -> Result<FfStatus, String> {
    let mut g = procs().lock().unwrap();
    let p = g.get_mut(&id).ok_or("ffmpeg is not running")?;
    let st = p.child.try_wait().map_err(|e| e.to_string())?;
    let log = p.log.lock().unwrap().clone();
    Ok(FfStatus { running: st.is_none(), code: st.and_then(|s| s.code()).unwrap_or(-1), log })
}
/// Runs ffmpeg to the end and returns its output (stdout), e.g. one frame as JPEG or the sound as WAV
#[tauri::command]
async fn ffmpeg_output(path: String, args: Vec<String>) -> Result<Response, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let out = no_window(&mut Command::new(&path)).args(&args).stdin(Stdio::null()).output().map_err(|e| format!("{path}: {e}"))?;
        if out.stdout.is_empty() {
            let e = String::from_utf8_lossy(&out.stderr).into_owned();
            let t: Vec<&str> = e.trim().lines().rev().take(4).collect();
            return Err(t.into_iter().rev().collect::<Vec<_>>().join("\n"));
        }
        Ok(Response::new(out.stdout))
    })
    .await
    .map_err(|e| e.to_string())?
}
/// ffmpeg's description of a media file (duration, streams, frame rate …)
#[tauri::command]
async fn ffmpeg_probe(path: String, file: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let out = no_window(&mut Command::new(&path)).args(["-hide_banner", "-i", &file]).stdin(Stdio::null()).output().map_err(|e| format!("{path}: {e}"))?;
        Ok(String::from_utf8_lossy(&out.stderr).into_owned())
    })
    .await
    .map_err(|e| e.to_string())?
}
fn ff_stdin(id: u32) -> Result<Arc<Mutex<Option<ChildStdin>>>, String> {
    procs().lock().unwrap().get(&id).map(|p| p.stdin.clone()).ok_or_else(|| "ffmpeg is not running".to_string())
}
fn ff_log(id: u32) -> String {
    procs().lock().unwrap().get(&id).map(|p| p.log.lock().unwrap().clone()).unwrap_or_default()
}
/// Sends data to ffmpeg (raw body, header "x-id"); waits while ffmpeg is busy
#[tauri::command]
async fn ffmpeg_write(request: Request<'_>) -> Result<(), String> {
    use std::io::Write;
    let InvokeBody::Raw(data) = request.body() else {
        return Err("ffmpeg_write: binary data expected".into());
    };
    let id: u32 = request.headers().get("x-id").and_then(|v| v.to_str().ok()).and_then(|v| v.parse().ok()).ok_or("ffmpeg_write: id missing")?;
    let data = data.clone();
    let stdin = ff_stdin(id)?;
    let r = tauri::async_runtime::spawn_blocking(move || {
        let mut g = stdin.lock().unwrap();
        match g.as_mut() { Some(w) => w.write_all(&data).map_err(|e| e.to_string()), None => Err("ffmpeg input closed".into()) }
    })
    .await
    .map_err(|e| e.to_string())?;
    r.map_err(|e| { let l = ff_log(id); format!("{e}\n{}", l.trim()) })
}
#[derive(Serialize)]
struct FfDone {
    code: i32,
    log: String,
}
/// Closes the input and waits until ffmpeg has finished the file
#[tauri::command]
async fn ffmpeg_finish(id: u32) -> Result<FfDone, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let p = procs().lock().unwrap().remove(&id);
        let Some(mut p) = p else { return Err("ffmpeg is not running".to_string()) };
        p.stdin.lock().unwrap().take(); // closing stdin = end of the frames
        let st = p.child.wait().map_err(|e| e.to_string())?;
        std::thread::sleep(std::time::Duration::from_millis(50));
        let log = p.log.lock().unwrap().clone();
        Ok(FfDone { code: st.code().unwrap_or(-1), log })
    })
    .await
    .map_err(|e| e.to_string())?
}
#[tauri::command]
fn ffmpeg_kill(id: u32) -> Result<(), String> {
    if let Some(mut p) = procs().lock().unwrap().remove(&id) {
        p.stdin.lock().unwrap().take();
        let _ = p.child.kill();
        let _ = p.child.wait();
    }
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![
            read_file, read_file_range, write_file, write_at, stat_path, read_dir, make_dir, remove_path, trash_paths, cli_paths,
            ffmpeg_info, ffmpeg_start, ffmpeg_write, ffmpeg_finish, ffmpeg_kill, ffmpeg_read, ffmpeg_status, ffmpeg_output, ffmpeg_probe
        ])
        .run(tauri::generate_context!())
        .expect("error while running StereoMate");
}
